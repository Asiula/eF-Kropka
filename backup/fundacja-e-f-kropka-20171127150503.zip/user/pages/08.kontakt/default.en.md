---
title: Kontakt
---

<div class="uk-flex uk-flex-center uk-flex-column" id="kontakt">

<h1> Fundacja eF kropka </h1>

fundacja@ef.org.pl  </br>
KRS: 0000382481    </br>
NIP: 9512336073    </br>
REGON: 142886373    </br>
Nr konta: 69203000451110000003721820     </br>
 
Jerzy Kłoskowski - Prezes Zarządu  </br>
	tel. 605 220 927  </br>
Joanna Krzyżanowska-Zbucka - Członek Zarządu  </br>
	tel. 601 671 573  </br>
Marta Niedźwiedzka - Członek Zarządu  </br>
	tel. 501 035 457  </br>
</div>