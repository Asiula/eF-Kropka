---
title: Home
---

#**Fundacja eF kropka**

Fundacja eFkropka to organizacja, która powstała z inicjatywy osób zawodowo zajmujących się leczeniem i pracą terapeutyczną na rzecz ludzi z doświadczeniem choroby psychicznej. Jako specjaliści mamy świadomość dużych potrzeb w zakresie rehabilitacji oraz adaptacji społecznej naszych beneficjentów i dostrzegamy deficyty w społecznej służbie zdrowia w związku z ciągle niewdrożonym Narodowym Programem Ochrony Zdrowia Psychicznego.

Celem naszych projektów jest zmiana stereotypów na temat chorób psychicznych utrwalonych w świadomości społecznej, a także w myśleniu o sobie samych pacjentów. W związku z tym, wraz z uczestnikami, chcemy aktywnie wyrównywać szanse, stwarzać możliwości rozwoju, a tym samym kreować lepszą jakość życia osób po doświadczeniu psychozy.
####  Choroba psychiczna nie musi i nie powinna wykluczać.

_Joanna Krzyżanowska-Zbucka_

_Marta Niedźwiedzka_

_Jerzy Kłoskowski_